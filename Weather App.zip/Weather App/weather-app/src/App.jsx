import WeatherForecast from './WeatherForecast';

function App() {
  return (
    <>
      <WeatherForecast/>
    </>
  )
}
export default App
